import {
  Action,
  createReducer,
  on
} from '@ngrx/store';

import * as ToDoActions from '../actions/todos.actions';
import { ITodosState } from '../../interfaces';

export const initialState: ITodosState = {
  todos: [
    {
      text: '1',
    },
    {
      text: '2',
    },
    {
      text: '3',
    }
  ],
};

const todosReducer = createReducer(
  initialState,
  on(ToDoActions.incrementTodosCount, (state) => {
    let copyOfTodos = state.todos.slice();
    copyOfTodos.push({ text: `${state.todos.length + 1}` });
    return { ...state,  ...{ todos: copyOfTodos } };
  }),

  on(ToDoActions.decrementTodosCount, (state) => {
    let copyOfTodos = state.todos.slice();
    copyOfTodos.splice(state.todos.length-1, 1);
    return { ...state,  ...{todos: copyOfTodos} };
  })
);

export function reducer(state: ITodosState, action: Action) {
  return todosReducer(state, action);
}
