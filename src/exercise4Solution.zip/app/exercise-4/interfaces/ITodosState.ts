import { ITodo } from '.';

export interface ITodosState {
  todos?: ITodo[];
}
