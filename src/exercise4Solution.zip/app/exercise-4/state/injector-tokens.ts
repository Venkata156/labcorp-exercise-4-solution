export const TODOS_STORE_TOKEN = 'todos';
