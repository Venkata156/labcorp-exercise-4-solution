import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { ITodo } from '../interfaces/ITodo';
import * as todosSelectors from './selectors/todos.selectors';
import * as todosActions from './actions/todos.actions';

@Injectable({
  providedIn: 'root',
})
export class TodosService {
  constructor(private store: Store<any>) {}

  get todosList$(): Observable<ITodo[]> {
    return this.store.pipe(select(todosSelectors.incrementOrDecrementTodosSelector));
  }

  incrementTodos(): void {
    this.store.dispatch(todosActions.incrementTodosCount());
  }

  decrementTodos(): void {
    this.store.dispatch(todosActions.decrementTodosCount());
  }
}
