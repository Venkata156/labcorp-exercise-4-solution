import { createFeatureSelector, createSelector } from "@ngrx/store";

import { TODOS_STORE_TOKEN } from "../injector-tokens";
import { ITodosState } from "../../interfaces";


export const selectFeature = createFeatureSelector<ITodosState>(TODOS_STORE_TOKEN);

export const incrementOrDecrementTodosSelector = createSelector(
    selectFeature,
    (state: ITodosState) => state.todos
)